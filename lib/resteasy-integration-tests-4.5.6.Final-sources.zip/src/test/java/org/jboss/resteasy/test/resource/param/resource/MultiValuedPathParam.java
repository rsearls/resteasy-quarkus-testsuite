package org.jboss.resteasy.test.resource.param.resource;

import java.util.LinkedList;

public class MultiValuedPathParam<E> extends LinkedList<E> {

   private static final long serialVersionUID = 1L;
}
