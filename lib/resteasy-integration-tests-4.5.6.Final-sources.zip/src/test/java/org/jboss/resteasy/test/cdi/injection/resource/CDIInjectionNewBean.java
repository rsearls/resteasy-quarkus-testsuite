package org.jboss.resteasy.test.cdi.injection.resource;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class CDIInjectionNewBean {
}
