package org.jboss.resteasy.test.providers.jaxb.resource;

public class GenericSuperInterfaceBaseResource {

   protected String name;
   protected String description;
   protected String id;

   /**
    * Gets the value of the name property.
    *
    * @return possible object is {@link String }
    */
   public String getName() {
      return name;
   }

   /**
    * Sets the value of the name property.
    *
    * @param value allowed object is {@link String }
    */
   public void setName(String value) {
      this.name = value;
   }

   public boolean isSetName() {
      return (this.name != null);
   }

   /**
    * Gets the value of the description property.
    *
    * @return possible object is {@link String }
    */
   public String getDescription() {
      return description;
   }

   /**
    * Sets the value of the description property.
    *
    * @param value allowed object is {@link String }
    */
   public void setDescription(String value) {
      this.description = value;
   }

   public boolean isSetDescription() {
      return (this.description != null);
   }
}
