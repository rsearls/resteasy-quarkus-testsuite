package org.jboss.resteasy.test.providers.jaxb.resource;

public class GenericSuperInterfaceIVdcQueryable {

}
