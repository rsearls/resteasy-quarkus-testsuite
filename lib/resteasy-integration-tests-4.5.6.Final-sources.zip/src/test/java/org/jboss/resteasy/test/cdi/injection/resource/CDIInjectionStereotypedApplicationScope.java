package org.jboss.resteasy.test.cdi.injection.resource;

@CDIInjectionScopeInheritingStereotype
public class CDIInjectionStereotypedApplicationScope {
   public void test() {
   }
}
