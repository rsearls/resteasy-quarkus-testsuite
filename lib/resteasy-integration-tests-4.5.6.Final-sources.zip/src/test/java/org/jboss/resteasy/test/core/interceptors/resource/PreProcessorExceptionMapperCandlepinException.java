package org.jboss.resteasy.test.core.interceptors.resource;

public class PreProcessorExceptionMapperCandlepinException extends RuntimeException {
}
