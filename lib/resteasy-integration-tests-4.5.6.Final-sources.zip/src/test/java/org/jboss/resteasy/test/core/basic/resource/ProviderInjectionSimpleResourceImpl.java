package org.jboss.resteasy.test.core.basic.resource;


public class ProviderInjectionSimpleResourceImpl implements ProviderInjectionSimpleResource {
   public String foo() {
      return "foo";
   }
}
