package org.jboss.resteasy.test.cdi.injection.resource;

import javax.ejb.Stateful;

@Stateful
public class CDIInjectionStatefulEJB {
}
