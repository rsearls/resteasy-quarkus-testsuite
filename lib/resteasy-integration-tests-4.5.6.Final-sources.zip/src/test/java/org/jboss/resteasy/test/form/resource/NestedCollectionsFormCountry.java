package org.jboss.resteasy.test.form.resource;

import javax.ws.rs.FormParam;

public class NestedCollectionsFormCountry {
   @FormParam("code")
   public String code;
}
